﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'zh-cn', {
	button: '模板',
	emptyListMsg: '(没有模板)',
	insertOption: '替换当前内容',
	options: '模板选项',
	selectPromptMsg: '请选择编辑器内容模板:',
	title: '内容模板'
});
