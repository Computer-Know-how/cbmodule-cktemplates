﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'es', {
	button: 'Plantillas',
	emptyListMsg: '(No hay plantillas definidas)',
	insertOption: 'Reemplazar el contenido actual',
	options: 'Opciones de plantillas',
	selectPromptMsg: 'Por favor selecciona la plantilla a abrir en el editor<br>(el contenido actual se perderá):',
	title: 'Contenido de Plantillas'
});
