﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'eo', {
	button: 'Ŝablonoj',
	emptyListMsg: '(Neniu ŝablono difinita)',
	insertOption: 'Anstataŭigi la nunan enhavon',
	options: 'Opcioj pri ŝablonoj',
	selectPromptMsg: 'Bonvolu selekti la ŝablonon por malfermi ĝin en la redaktilo',
	title: 'Enhavo de ŝablonoj'
});
