﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'cs', {
	button: 'Šablony',
	emptyListMsg: '(Není definována žádná šablona)',
	insertOption: 'Nahradit aktuální obsah',
	options: 'Nastavení šablon',
	selectPromptMsg: 'Prosím zvolte šablonu pro otevření v editoru<br>(aktuální obsah editoru bude ztracen):',
	title: 'Šablony obsahu'
});
