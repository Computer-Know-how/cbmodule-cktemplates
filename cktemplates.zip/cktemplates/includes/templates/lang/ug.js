﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'ug', {
	button: 'قېلىپ',
	emptyListMsg: '(قېلىپ يوق)',
	insertOption: 'نۆۋەتتىكى مەزمۇننى ئالماشتۇر',
	options: 'قېلىپ تاللانمىسى',
	selectPromptMsg: 'تەھرىرلىگۈچنىڭ مەزمۇن قېلىپىنى تاللاڭ:',
	title: 'مەزمۇن قېلىپى'
});
