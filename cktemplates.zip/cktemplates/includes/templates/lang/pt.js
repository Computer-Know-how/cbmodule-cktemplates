﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'pt', {
	button: 'Modelos',
	emptyListMsg: '(Sem modelos definidos)',
	insertOption: 'Substituir conteúdos actuais',
	options: 'Opções do Modelo',
	selectPromptMsg: 'Por favor, seleccione o modelo a abrir no editor<br>(o conteúdo actual será perdido):',
	title: 'Modelo de Conteúdo'
});
