﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'uk', {
	button: 'Шаблони',
	emptyListMsg: '(Не знайдено жодного шаблону)',
	insertOption: 'Замінити поточний вміст',
	options: 'Опції шаблону',
	selectPromptMsg: 'Оберіть, будь ласка, шаблон для відкриття в редакторі<br>(поточний зміст буде втрачено):',
	title: 'Шаблони змісту'
});
