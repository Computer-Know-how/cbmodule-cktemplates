﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'fr', {
	button: 'Modèles',
	emptyListMsg: '(Aucun modèle disponible)',
	insertOption: 'Remplacer le contenu actuel',
	options: 'Options des modèles',
	selectPromptMsg: 'Veuillez sélectionner le modèle pour l\'ouvrir dans l\'éditeur',
	title: 'Contenu des modèles'
});
