﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'ms', {
	button: 'Templat',
	emptyListMsg: '(Tiada Templat Disimpan)',
	insertOption: 'Replace actual contents', // MISSING
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Sila pilih templat untuk dibuka oleh editor<br>(kandungan sebenar akan hilang):',
	title: 'Templat Kandungan'
});
