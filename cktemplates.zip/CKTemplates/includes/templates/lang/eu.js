﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'eu', {
	button: 'Txantiloiak',
	emptyListMsg: '(Ez dago definitutako txantiloirik)',
	insertOption: 'Ordeztu oraingo edukiak',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Mesedez txantiloia aukeratu editorean kargatzeko<br>(orain dauden edukiak galduko dira):',
	title: 'Eduki Txantiloiak'
});
