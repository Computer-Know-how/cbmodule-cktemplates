﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'pt-br', {
	button: 'Modelos de layout',
	emptyListMsg: '(Não foram definidos modelos de layout)',
	insertOption: 'Substituir o conteúdo atual',
	options: 'Opções de Template',
	selectPromptMsg: 'Selecione um modelo de layout para ser aberto no editor<br>(o conteúdo atual será perdido):',
	title: 'Modelo de layout de conteúdo'
});
