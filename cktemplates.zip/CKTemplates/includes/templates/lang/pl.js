﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'pl', {
	button: 'Szablony',
	emptyListMsg: '(Brak zdefiniowanych szablonów)',
	insertOption: 'Zastąp obecną zawartość',
	options: 'Opcje szablonów',
	selectPromptMsg: 'Wybierz szablon do otwarcia w edytorze<br>(obecna zawartość okna edytora zostanie utracona):',
	title: 'Szablony zawartości'
});
