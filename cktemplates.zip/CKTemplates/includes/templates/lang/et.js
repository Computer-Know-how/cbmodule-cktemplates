﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'et', {
	button: 'Mall',
	emptyListMsg: '(Ühtegi malli ei ole defineeritud)',
	insertOption: 'Praegune sisu asendatakse',
	options: 'Malli valikud',
	selectPromptMsg: 'Palun vali mall, mis avada redaktoris<br />(praegune sisu läheb kaotsi):',
	title: 'Sisumallid'
});
