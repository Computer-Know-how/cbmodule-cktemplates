﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'ja', {
	button: 'テンプレート(雛形)',
	emptyListMsg: '(テンプレートが定義されていません)',
	insertOption: '現在のエディタの内容と置換えをします',
	options: 'テンプレートオプション',
	selectPromptMsg: 'エディターで使用するテンプレートを選択してください。<br>(現在のエディタの内容は失われます):',
	title: 'テンプレート内容'
});
