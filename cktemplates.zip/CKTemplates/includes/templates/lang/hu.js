﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'hu', {
	button: 'Sablonok',
	emptyListMsg: '(Nincs sablon megadva)',
	insertOption: 'Kicseréli a jelenlegi tartalmat',
	options: 'Sablon opciók',
	selectPromptMsg: 'Válassza ki melyik sablon nyíljon meg a szerkesztőben<br>(a jelenlegi tartalom elveszik):',
	title: 'Elérhető sablonok'
});
