﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'gl', {
	button: 'Plantillas',
	emptyListMsg: '(Non hai plantillas definidas)',
	insertOption: 'Replace actual contents', // MISSING
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Por favor, seleccione a plantilla a abrir no editor<br>(o contido actual perderase):',
	title: 'Plantillas de Contido'
});
