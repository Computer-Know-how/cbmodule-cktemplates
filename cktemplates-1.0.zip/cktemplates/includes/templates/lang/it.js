﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'it', {
	button: 'Modelli',
	emptyListMsg: '(Nessun modello definito)',
	insertOption: 'Cancella il contenuto corrente',
	options: 'Opzioni del Modello',
	selectPromptMsg: 'Seleziona il modello da aprire nell\'editor<br />(il contenuto attuale verrà eliminato):',
	title: 'Contenuto dei modelli'
});
